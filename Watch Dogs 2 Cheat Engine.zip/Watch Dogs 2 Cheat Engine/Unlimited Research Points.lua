local research = getEntity("Research")
research.points = 1000000