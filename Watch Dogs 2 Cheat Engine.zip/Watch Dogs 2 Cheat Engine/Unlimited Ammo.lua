local player = getEntity("Player")
player.ammo = 1000000