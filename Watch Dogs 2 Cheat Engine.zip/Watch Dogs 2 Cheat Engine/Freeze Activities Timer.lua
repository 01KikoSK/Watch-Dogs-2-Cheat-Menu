local timer = getEntity("Timer")
timer.freeze = true