local research = getEntity("Research")
research.points = 10000000