local lenny = getEntity("Lenny")
lenny.time = 0