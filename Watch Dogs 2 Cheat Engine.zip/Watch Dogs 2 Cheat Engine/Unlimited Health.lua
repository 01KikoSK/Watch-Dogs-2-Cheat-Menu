local player = getEntity("Player")
player.health = 1000000