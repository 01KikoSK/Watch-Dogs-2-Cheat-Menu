local player = getEntity("Player")
player.battery = 1000000