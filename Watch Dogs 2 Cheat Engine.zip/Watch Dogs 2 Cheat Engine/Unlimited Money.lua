local player = getEntity("Player")
player.money = 999999999