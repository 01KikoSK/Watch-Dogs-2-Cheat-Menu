local player = getEntity("Player")
player.reload = false